import React, { useEffect, useState } from 'react';
import './App.css';

import awsExports from "./aws-exports";
import Amplify, { API, graphqlOperation, Storage } from 'aws-amplify';
import { listProjects } from './graphql/queries';

Amplify.configure(awsExports);

const Preview = () => {
  const [projects, setProjects] = useState([])

  const [Images, setImages] = useState([])

  useEffect(() => {
      fetchImages()
  }, [])

  async function fetchImages() {
    let imageKeys = await Storage.list("")
    console.log('imageKeys 1: ', imageKeys)
    imageKeys = await Promise.all(imageKeys.map(async k => {
      const signedUrl = await Storage.get(k.key)
      return signedUrl
    }))
    console.log('imageKeys 2: ', imageKeys)
    setImages(imageKeys)
  }

  useEffect(() => {
    fetchProjects()
  }, [])

  async function fetchProjects() {
    try {
      const projectData = await API.graphql(graphqlOperation(listProjects))
      const projects = projectData.data.listProjects.items
      setProjects(projects)
    } catch (err) { console.log('error fetching projects') }
  }

  return (
    <div style={styles.root}>
        <h1>HOME</h1>  
        <h3>Together with a friends, internet and a smartphone you can take part.</h3>
      <h2>Article</h2>
      <div className="container app"> {
        projects.map((project, index) => (
          <div key={project.id ? project.id : index} style={styles.project}>
            <p style={styles.projectName}>{project.name}</p>
            <p style={styles.projectDescription}>{project.description}</p>
            <hr />
          </div>
        ))
      }</div>
      <h2>Latest Images</h2>
      <ul className="imgList">{
        Images.map((image, index) => (
          <div key={image.id ? image.id : index}><img className="imageStyle" alt="" src={image} key={image} style={{ width: 155, margin: 10 }}  /></div>
        )) 
      }</ul>
    </div>
  )
}

const styles = {
  root: { amplifyPrimaryColor: '#fff', width: 320, margin: '10', display: 'flex', flexDirection: 'column', justifyContent: 'left', padding: 20  },
  project: {  marginBottom: 15 },
  input: { border: 'none', backgroundColor: '#ddd', marginBottom: 10, padding: 8, fontSize: 18 },
  projectName: { fontSize: 20, fontWeight: 'bold' },
  projectDescription: { marginBottom: 8 },
  button: { backgroundColor: 'black', color: 'white', outline: 'none', fontSize: 18, padding: '12px 0px' }
}

export default Preview;