//import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import reportWebVitals from './reportWebVitals';

import Layout from "./components/Layout";

//import Home from "./Home";
import Preview from './Preview';  
import Dashboard from './dashboard';

//import Tour from './components/Product';
import Tours from './components/Products';
import TourAdmin from './components/ProductAdmin';

// src/index.js
import Amplify from "aws-amplify";
import config from "./aws-exports";
Amplify.configure(config);

export default function Index() {
  return (
    <BrowserRouter>
      <Routes>
          <Route path="/" element={<Layout />}>
          <Route index element={<Preview />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="tours" element={<Tours />} />
          <Route path="admin" element={<TourAdmin />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

ReactDOM.render(<Index />, document.getElementById("root"));
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();


/*<Route exact path="/products" render={(props) => <Products {...props} auth={authProps} />} />
<Route exact path="/admin" render={(props) => <ProductAdmin {...props} auth={authProps} />} />

          <Route index element={<Home />} />
          <Route path="preview" element={<Preview />} />*/