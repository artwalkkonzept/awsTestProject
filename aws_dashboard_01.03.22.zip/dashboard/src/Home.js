import React from 'react';


function Home() {
    return (
      
      <div>
        <h1>HOME</h1>  
        <h3>Together with a friends, internet and a smartphone you can take part.</h3>
      </div>
    );
  }
  
  const styles = {
    root: { amplifyPrimaryColor: '#fff', width: 320, margin: '10', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 20  },
    project: {  marginBottom: 15 },
    input: { border: 'none', backgroundColor: '#ddd', marginBottom: 10, padding: 8, fontSize: 18 },
    projectName: { fontSize: 20, fontWeight: 'bold' },
    projectDescription: { fontSize: 18, marginBottom: 8 },
    button: { backgroundColor: 'black', color: 'white', outline: 'none', fontSize: 18, padding: '12px 0px' }    
  }
  
  export default Home;
  
  