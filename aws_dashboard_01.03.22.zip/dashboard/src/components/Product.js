import React, { Component, Fragment }  from 'react';
//import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

export default class TourAdmin extends Component {

  state = {
    isEditMode: false,
    updatedtourname: this.props.name
  }

  handleTourEdit = event => {
    event.preventDefault();
    this.setState({ isEditMode: true });
  }

  handleEditSave = event => {
    event.preventDefault();
    this.setState({ isEditMode: false });
    this.props.handleUpdateTour(this.props.id, this.state.updatedtourname);
  }

  onAddTourNameChange = event => this.setState({ "updatedtourname": event.target.value });

  render() {
    return (
      <div style={styles.root}>
        
        {
          this.state.isEditMode 
          ? <div  style={styles.root}>
              <h1>Edit Tour</h1>
              <input 
                 style={styles.input}
                type="text" 
                placeholder="Enter name"
                value={this.state.updatedtourname}
                onChange={this.onAddTourNameChange}
              />
              <p className="tour-id">id: { this.props.id }</p>
              <button  style={styles.button} type="submit" 
                className="button"
                onClick={ this.handleEditSave }
              >save</button>
            </div>
          : <div>
              <p style={styles.projectName}>{ this.props.name }</p>
              <p style={styles.projectDescription}> { this.props.id }</p>
            </div>
        }
        {
          this.props.isAdmin && 
          <Fragment>
            <button style={styles.button} href="/" onClick={this.handleTourEdit}  className="edit">
            Edit
            </button>
            <button style={styles.button} onClick={event => this.props.handleDeleteTour(this.props.id, event)} className="delete">Delete</button>
          </Fragment>
        }
      </div>
    )
  }
}

const styles = {
  root: { amplifyPrimaryColor: '#fff', width: 320, margin: '10', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 20  },
  project: {  marginBottom: 15 },
  input: { border: 'none', backgroundColor: '#ddd', marginBottom: 10, padding: 8, fontSize: 18 },
  projectName: { fontSize: 20, fontWeight: 'bold' },
  projectDescription: { fontSize: 18, marginBottom: 8 },
  button: { backgroundColor: 'black', color: 'white', outline: 'none', fontSize: 18, padding: '12px 0px' }
}
/*<FontAwesomeIcon icon="edit" />*/