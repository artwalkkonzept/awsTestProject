//import React from 'react';
import { Outlet, Link } from "react-router-dom";
import Gallery from "./Logo/Gallery";

const Layout = () => {
  return (
    <>
      <nav>
        <ul>
            <li>
            <Gallery />
            </li>
            <li>
              <Link className="navLink" to="/">HOME</Link>
            </li>
            <li>
              <Link className="navLink" to="/tours">TOURS</Link>
            </li>
            <li>
              <Link className="navLink" to="/dashboard">DASHBOARD</Link>
            </li>
        </ul>
      </nav>
      <Outlet />
    </>
    
  )
};

export default Layout;