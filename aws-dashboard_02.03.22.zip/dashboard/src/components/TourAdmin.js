import React, { Component, Fragment } from 'react';
import Tour from './Tour';
import axios from "axios";
const config = require('../config.json');

export default class TourAdmin extends Component {

  state = {
    newtour: { 
      "tourname": "", 
      "id": ""
    },
    tours: []
  }

  handleAddTour = async (id, event) => {
    event.preventDefault();
    // add call to AWS API Gateway add tour endpoint here
    try {
      const params = {
        "id": id,
        "tourname": this.state.newtour.tourname
      };
      await axios.post(`${config.api.invokeUrl}/tours/${id}`, params);
      this.setState({ tours: [...this.state.tours, this.state.newtour] });
      this.setState({ newtour: { "tourname": "", "id": "" }});
    }catch (err) {
      console.log(`An error has occurred: ${err}`);
    }
  }

  handleUpdateTour = async (id, name) => {
    // add call to AWS API Gateway update tour endpoint here
    try {
      const params = {
        "id": id,
        "tourname": name
      };
      await axios.patch(`${config.api.invokeUrl}/tours/${id}`, params);
      const tourToUpdate = [...this.state.tours].find(tour => tour.id === id);
      const updatedTours = [...this.state.tours].filter(tour => tour.id !== id);
      tourToUpdate.tourname = name;
      updatedTours.push(tourToUpdate);
      this.setState({tours: updatedTours});
    }catch (err) {
      console.log(`Error updating tour: ${err}`);
    }
  }

  handleDeleteTour = async (id, event) => {
    event.preventDefault();
    // add call to AWS API Gateway delete tour endpoint here
    try {
      await axios.delete(`${config.api.invokeUrl}/tours/${id}`);
      const updatedTours = [...this.state.tours].filter(tour => tour.id !== id);
      this.setState({tours: updatedTours});
    }catch (err) {
      console.log(`Unable to delete tour: ${err}`);
    }
  }

  fetchTours = async () => {
    // add call to AWS API Gateway to fetch tours here
    // then set them in state
    try {
      const res = await axios.get(`${config.api.invokeUrl}/tours`);
      const tours = res.data;
      this.setState({ tours: tours });
    } catch (err) {
      console.log(`An error has occurred: ${err}`);
    }
  }

  onAddTourNameChange = event => this.setState({ newtour: { ...this.state.newtour, "tourname": event.target.value } });
  onAddTourIdChange = event => this.setState({ newtour: { ...this.state.newtour, "id": event.target.value } });

  componentDidMount = () => {
    this.fetchTours();
  }

  render() {
    return (
      <Fragment>
        <section>
          <div>
            <div style={styles.root}>
            <h1>Tour Admin</h1>
            <h2>Add, remove and update</h2>
            </div>
            <br />
            <div className="columns">
              <div className="column">
                <form onSubmit={event => this.handleAddTour(this.state.newtour.id, event)}>
                  <div className="field">
                    <div style={styles.root} className="control">
                      <input style={styles.input}
                        className="input"
                        type="text" 
                        placeholder="Enter name"
                        value={this.state.newtour.tourname}
                        onChange={this.onAddTourNameChange}
                      />
                    </div>
                    <div  style={styles.root} className="control">
                      <input style={styles.input}
                        className="input"
                        type="text" 
                        placeholder="Enter id"
                        value={this.state.newtour.id}
                        onChange={this.onAddTourIdChange}
                      />
                    </div>
                    <div  style={styles.root} className="control">
                      <button style={styles.button} type="submit" className="button">
                        Add
                      </button>
                    </div>
                  </div>
                </form>
              </div>
              <div className="column">
                <div className="tile">
                  <div className="tile">
                    { 
                      this.state.tours.map((tour, index) => 
                        <Tour 
                          isAdmin={true}
                          handleUpdateTour={this.handleUpdateTour}
                          handleDeleteTour={this.handleDeleteTour} 
                          name={tour.tourname} 
                          id={tour.id}
                          key={tour.id}
                        />)
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </Fragment>
    )
  }
}

const styles = {
  root: { amplifyPrimaryColor: '#fff', width: 320, margin: '10', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 20  },
  project: {  marginBottom: 15 },
  input: { border: 'none', backgroundColor: '#ddd', marginBottom: 10, padding: 8, fontSize: 18 },
  projectName: { fontSize: 20, fontWeight: 'bold' },
  projectDescription: { fontSize: 18, marginBottom: 8 },
  button: { backgroundColor: 'black', color: 'white', outline: 'none', fontSize: 18, padding: '12px 0px' }
}