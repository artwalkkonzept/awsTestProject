import { Link } from "react-router-dom";
import CompanyLogo from "./ArtWalk_Logo final_ww.png";

function Gallery() {
  return (
      <Link className="navLink" to="/">
        <img href="/" src={CompanyLogo}  style={{ width:20, marginLeft: 5, position: "fixed", zIndex: 100, left: 5 }} alt="Artwalk Inc. logo"/>
      </Link>
  );
}

export default Gallery