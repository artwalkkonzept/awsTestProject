import React, { Component, Fragment } from 'react';
import Tour from './Tour';
import axios from "axios";
const config = require('../config.json');

export default class tours extends Component {

  state = {
    newtour: null,
    tours: []
  }

  fetchTours = async () => {
    // add call to AWS API Gateway to fetch tours here
    // then set them in state
    try {
      const res = await axios.get(`${config.api.invokeUrl}/tours`);
      const tours = res.data;
      this.setState({ tours: tours });
    } catch (err) {
      console.log(`An error has occurred: ${err}`);
    }
  }

  componentDidMount = () => {
    this.fetchTours();
  }

  render() {
    return (
      <Fragment>
        <section>
          <div style={styles.root}>
            <h1>ART TOUR</h1>
            <p className="subtitle"></p>
            <br />
                  <div style={styles.projectDescription}>
                    { 
                      this.state.tours && this.state.tours.length > 0
                      ? this.state.tours.map(tour => <Tour name={tour.tourname} key={tour.id} />)
                      : <div className="tile notification-warning"></div>
                    }
                  </div>
                </div>
        </section>
      </Fragment>
    )
  }
}

const styles = {
  root: { amplifyPrimaryColor: '#fff', width: 320, margin: '10', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 20  },
  project: {  marginBottom: 15 },
  input: { border: 'none', backgroundColor: '#ddd', marginBottom: 10, padding: 8, fontSize: 18 },
  projectName: { fontSize: 20, fontWeight: 'bold' },
  projectDescription: { fontSize: 18, marginBottom: 8 },
  button: { backgroundColor: 'black', color: 'white', outline: 'none', fontSize: 18, padding: '12px 0px' }
}