import React, { useEffect, useState } from 'react';
import './App.css';

import awsExports from "./aws-exports";
import { withAuthenticator, AmplifySignOut } from '@aws-amplify/ui-react';
import Amplify, { API, graphqlOperation, Storage } from 'aws-amplify';
import { createProject } from './graphql/mutations';
import { listProjects } from './graphql/queries';

import { Link } from "react-router-dom";


Amplify.configure(awsExports);

const initialState = { name: '', description: '' }

const App = () => {
  const [formState, setFormState] = useState(initialState)
  const [projects, setProjects] = useState([])

  useEffect(() => {
    fetchProjects()
  }, [])

  function setInput(key, value) {
    setFormState({ ...formState, [key]: value })
  }

  const [Images, setImages] = useState([])
  useEffect(() => {
    fetchImages()
  }, [])

  async function fetchImages() {
    let imageKeys = await Storage.list("")
    console.log('imageKeys 1: ', imageKeys)
    imageKeys = await Promise.all(imageKeys.map(async k => {
      const signedUrl = await Storage.get(k.key)
      return signedUrl
    }))

    console.log('imageKeys 2: ', imageKeys)
    setImages(imageKeys)
  }
  async function onChange(e) {
    const file = e.target.files[0]
    const result = await Storage.put(file.name, file)
    console.log("result: ", result)
    fetchImages()
  }

  async function fetchProjects() {
    try {
      const projectData = await API.graphql(graphqlOperation(listProjects))
      const projects = projectData.data.listProjects.items
      setProjects(projects)
    } catch (err) { console.log('error fetching projects') }
  }

  async function addProject() {
    try {
      if (!formState.name || !formState.description) return
      const project = { ...formState }
      setProjects([...projects, project])
      setFormState(initialState)
      await API.graphql(graphqlOperation(createProject, {input: project}))
    } catch (err) {
      console.log('error creating project:', err)
    }
  }

  return (
    <div style={styles.root}>
      <AmplifySignOut buttonText="Log out"></AmplifySignOut>

      <h2>Create Tour</h2>
      <>
      <button style={styles.button}><Link className="navLink" to="/admin"> <strong> CURATE ART TOUR </strong></Link></button>
      </>

      <h2>Create Article</h2>
      <input
        onChange={event => setInput('name', event.target.value)}
        style={styles.input}
        value={formState.name}
        placeholder="Name"
      />
      <input
        onChange={event => setInput('description', event.target.value)}
        style={styles.input}
        value={formState.description}
        placeholder="Description"
      />
      <button style={styles.button} onClick={addProject}>Create Article</button>
      <div className="container dashboard">{
          projects.map((project, index) => 
            (
              <div key={project.id ? project.id : index} style={styles.project}>
                <p style={styles.projectName}>{project.name}</p>
                <p style={styles.projectDescription}>{project.description}</p>
              </div>
          ) )
        }</div>
  
        <h2>Add Image (jpg, png, gif)</h2>
        <input
          type="file"
          onChange={onChange}
        />
        {
          Images.map(image => (
            <img alt="" src={image} key={image} style={{ width: 320, marginRight: 10, marginTop: 10}} />
          )) 
        }
      </div>
  )
}

const styles = {
  root: { amplifyPrimaryColor: '#fff', width: 320, margin: '10', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 20  },
  project: {  marginBottom: 15 },
  input: { border: 'none', backgroundColor: '#ddd', marginBottom: 10, padding: 8, fontSize: 18 },
  projectName: { fontSize: 20, fontWeight: 'bold' },
  projectDescription: { fontSize: 18, marginBottom: 8 },
  button: { backgroundColor: 'black', color: 'white', outline: 'none', fontSize: 18, padding: '12px 0px' }
}

export default withAuthenticator(App)